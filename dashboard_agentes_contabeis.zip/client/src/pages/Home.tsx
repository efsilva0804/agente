import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, CheckCircle2, Clock, Zap } from "lucide-react";

interface Agent {
  id: string;
  name: string;
  category: string;
  status: "idle" | "running" | "error";
  tasksCompleted: number;
  lastActivity: string;
}

interface SystemStats {
  totalAgents: number;
  activeAgents: number;
  queuedTasks: number;
  successRate: number;
}

const AGENTS: Agent[] = [
  // Fiscal
  { id: "atlas", name: "Atlas", category: "Fiscal", status: "idle", tasksCompleted: 124, lastActivity: "2 min atrás" },
  { id: "clavis", name: "Clavis", category: "Fiscal", status: "idle", tasksCompleted: 89, lastActivity: "5 min atrás" },
  { id: "simbio", name: "Simbio", category: "Fiscal", status: "idle", tasksCompleted: 156, lastActivity: "1 min atrás" },
  { id: "magnus", name: "Magnus", category: "Fiscal", status: "idle", tasksCompleted: 92, lastActivity: "3 min atrás" },
  { id: "orion", name: "Orion", category: "Fiscal", status: "idle", tasksCompleted: 67, lastActivity: "7 min atrás" },
  // DP
  { id: "cronos", name: "Cronos", category: "DP", status: "idle", tasksCompleted: 201, lastActivity: "1 min atrás" },
  { id: "calculus", name: "Calculus", category: "DP", status: "idle", tasksCompleted: 178, lastActivity: "4 min atrás" },
  { id: "tributus_dp", name: "Tributus DP", category: "DP", status: "idle", tasksCompleted: 145, lastActivity: "2 min atrás" },
  { id: "socialis", name: "Socialis", category: "DP", status: "idle", tasksCompleted: 134, lastActivity: "6 min atrás" },
  // Contabilidade
  { id: "syncro", name: "Syncro", category: "Contabilidade", status: "idle", tasksCompleted: 198, lastActivity: "1 min atrás" },
  { id: "logos", name: "Logos", category: "Contabilidade", status: "idle", tasksCompleted: 167, lastActivity: "3 min atrás" },
  { id: "visio", name: "Visio", category: "Contabilidade", status: "idle", tasksCompleted: 112, lastActivity: "5 min atrás" },
  { id: "prompt", name: "Prompt", category: "Contabilidade", status: "idle", tasksCompleted: 234, lastActivity: "1 min atrás" },
  // Especializado
  { id: "declara", name: "Declara", category: "Especializado", status: "idle", tasksCompleted: 89, lastActivity: "8 min atrás" },
  { id: "socius", name: "Socius", category: "Especializado", status: "idle", tasksCompleted: 56, lastActivity: "10 min atrás" },
  { id: "strategos", name: "Strategos", category: "Especializado", status: "idle", tasksCompleted: 73, lastActivity: "4 min atrás" },
  { id: "evolutio", name: "Evolutio", category: "Especializado", status: "idle", tasksCompleted: 45, lastActivity: "12 min atrás" },
];

const SYSTEM_STATS: SystemStats = {
  totalAgents: 17,
  activeAgents: 0,
  queuedTasks: 0,
  successRate: 98.5,
};

const getStatusColor = (status: string) => {
  switch (status) {
    case "idle":
      return "bg-green-100 text-green-800";
    case "running":
      return "bg-blue-100 text-blue-800";
    case "error":
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case "idle":
      return <CheckCircle2 className="w-4 h-4" />;
    case "running":
      return <Zap className="w-4 h-4 animate-pulse" />;
    case "error":
      return <AlertCircle className="w-4 h-4" />;
    default:
      return <Clock className="w-4 h-4" />;
  }
};

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [agents, setAgents] = useState(AGENTS);

  const categories = ["Todos", "Fiscal", "DP", "Contabilidade", "Especializado"];
  
  const filteredAgents = selectedCategory === "Todos" 
    ? agents 
    : agents.filter(a => a.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Dashboard de Agentes Contábeis</h1>
              <p className="text-slate-600 mt-1">Sistema de Monitoramento e Gestão</p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline">Configurações</Button>
              <Button>Submeter Tarefa</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 bg-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Total de Agentes</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{SYSTEM_STATS.totalAgents}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Agentes Ativos</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{SYSTEM_STATS.activeAgents}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Tarefas na Fila</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{SYSTEM_STATS.queuedTasks}</p>
              </div>
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-amber-600" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Taxa de Sucesso</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{SYSTEM_STATS.successRate}%</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </Card>
        </div>

        {/* Agents Grid */}
        <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-slate-900 mb-4">Especialistas Virtuais</h2>
            <div className="flex gap-2 flex-wrap">
              {categories.map(cat => (
                <Button
                  key={cat}
                  variant={selectedCategory === cat ? "default" : "outline"}
                  onClick={() => setSelectedCategory(cat)}
                  className="rounded-full"
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAgents.map(agent => (
              <Card key={agent.id} className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-slate-900">{agent.name}</h3>
                    <p className="text-xs text-slate-500 mt-1">{agent.category}</p>
                  </div>
                  <Badge className={`${getStatusColor(agent.status)} flex items-center gap-1`}>
                    {getStatusIcon(agent.status)}
                    <span className="capitalize">{agent.status}</span>
                  </Badge>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Tarefas Concluídas:</span>
                    <span className="font-medium text-slate-900">{agent.tasksCompleted}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Última Atividade:</span>
                    <span className="font-medium text-slate-900">{agent.lastActivity}</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full mt-4 text-sm">
                  Ver Detalhes
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
